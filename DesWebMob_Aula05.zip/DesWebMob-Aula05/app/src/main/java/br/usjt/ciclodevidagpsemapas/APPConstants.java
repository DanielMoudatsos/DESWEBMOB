/**
 * Daniel Moudatsos Strassacapa Rodrigues R.A- 81716932
 */

package br.usjt.ciclodevidagpsemapas;

public class APPConstants {
    public static final long REQUEST_LOCATION_UPDATE_MIN_TIME = 2000;
    public static final long REQUEST_LOCATION_UPDATE_MIN_DISTANCE = 200;
}
